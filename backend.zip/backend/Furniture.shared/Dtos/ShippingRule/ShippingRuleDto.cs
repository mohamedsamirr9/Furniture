﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Furniture.shared.Dtos.ShippingRule
{
    public class ShippingRuleDto
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } 
        public string City { get; set; } 
        public decimal Price { get; set; }
    }
}
